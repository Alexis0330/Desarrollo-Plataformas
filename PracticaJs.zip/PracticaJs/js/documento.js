function saludar(){
    alert("Mi primer Script");
}
function sumar(){
    numero1 = parseInt(document.getElementById("n1").value);
    numero2 = parseInt(document.getElementById("n2").value);
    suma = numero1 + numero2;
    alert("La suma es: " + suma);
}
function invertirCad(){
    var cadenaObt = document.getElementById("cadena").innerText;
    var vector = cadenaObt.split(''); //arreglo de caracteres
    var reversa = vector.reverse(); //invertir el arreglo
    var cadenaInvertida = reversa.join(''); //Une el arreglo en una sola cadena
    document.write(cadenaInvertida);
    //alert("La cadena invertida es: " + cadenaInvertida);
}
function validarFormulario1(){
    var nombres = document.getElementById("nombres").value;
    if(nombres == ""){
        alert("Escriba sus nombres >:C")
    }else{
        alert("mmm nop");
    }
}